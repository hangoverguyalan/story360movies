</div>
<!--</container fluid>-->

</div>
<!--</container all>-->

<div class="bw_footer">
	<div class="bw_footer_width">
		<?php get_template_part( 'footer_url' ); ?>
	</div>
</div>

<?php wp_footer(); ?>
</body>
</html>